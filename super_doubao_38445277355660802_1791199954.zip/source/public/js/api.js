/**
 * 云屋 CLOUD 商城 - API 适配层
 * 统一前端数据访问入口：
 *  - 本地全栈运行：请求真实 Node 后端（/api/*）
 *  - 在线 Demo 部署（无后端）：自动降级到内置模拟数据（SHOP_PRODUCTS + localStorage）
 * 两种模式下前端业务代码完全一致。
 */
const Api = (() => {
  let backendMode = null; // null=未检测, true=真实后端, false=模拟
  const LS_CART = 'cloud_cart';
  const LS_ORDERS = 'cloud_orders';
  const LS_USER = 'cloud_user';

  /* ---------------- 后端检测 ---------------- */
  async function detectBackend() {
    if (backendMode !== null) return backendMode;
    // file:// 协议下 fetch 会被 CORS 拦截，直接判定为模拟模式（在线 Demo 场景）
    if (location.protocol === 'file:') {
      backendMode = false;
      return backendMode;
    }
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 2500);
      const res = await fetch('/api/health', { signal: ctrl.signal });
      clearTimeout(timer);
      backendMode = res.ok;
    } catch (e) {
      backendMode = false;
    }
    return backendMode;
  }

  /* ---------------- 模拟层：购物车 ---------------- */
  function mockGetCart() {
    try { return JSON.parse(localStorage.getItem(LS_CART)) || []; }
    catch { return []; }
  }
  function mockSaveCart(cart) {
    localStorage.setItem(LS_CART, JSON.stringify(cart));
  }

  /* ---------------- 模拟层：订单 ---------------- */
  function mockGenOrderNo() {
    const d = new Date();
    const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
    const rand = String(Math.floor(1000 + Math.random() * 9000));
    return `CLOUD-${ymd}-${rand}`;
  }
  function mockGetOrders() {
    try { return JSON.parse(localStorage.getItem(LS_ORDERS)) || []; }
    catch { return []; }
  }

  /* ---------------- 商品 ---------------- */
  /** 获取商品列表（支持搜索/筛选/排序/分页，返回与后端一致结构） */
  async function getProducts(params = {}) {
    if (await detectBackend()) {
      const qs = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') qs.set(k, v);
      });
      const res = await fetch(`/api/products?${qs.toString()}`);
      const json = await res.json();
      if (json.code !== 0) throw new Error(json.message || '商品列表获取失败');
      return json.data;
    }
    // ---- 模拟实现：与后端逻辑保持一致 ----
    let list = SHOP_PRODUCTS.slice();
    if (params.keyword) {
      const kw = params.keyword.toLowerCase();
      list = list.filter((p) =>
        [p.name, p.description, p.category, ...(p.tags || [])].join(' ').toLowerCase().includes(kw)
      );
    }
    if (params.category) list = list.filter((p) => p.category === params.category);
    if (params.minPrice !== undefined && params.minPrice !== '') list = list.filter((p) => p.price >= Number(params.minPrice));
    if (params.maxPrice !== undefined && params.maxPrice !== '') list = list.filter((p) => p.price <= Number(params.maxPrice));
    switch (params.sort) {
      case 'priceAsc': list.sort((a, b) => a.price - b.price); break;
      case 'priceDesc': list.sort((a, b) => b.price - a.price); break;
      case 'rating': list.sort((a, b) => b.rating - a.rating); break;
      case 'sales': list.sort((a, b) => b.sales - a.sales); break;
      default: list.sort((a, b) => b.sales - a.sales);
    }
    const total = list.length;
    const page = Math.max(1, Number(params.page) || 1);
    const pageSize = Math.min(60, Math.max(1, Number(params.pageSize) || 12));
    return {
      list: list.slice((page - 1) * pageSize, page * pageSize),
      total,
      page,
      pageSize,
      categories: [...new Set(SHOP_PRODUCTS.map((p) => p.category))],
    };
  }

  /** 获取商品详情 */
  async function getProduct(id) {
    if (await detectBackend()) {
      const res = await fetch(`/api/products/${id}`);
      const json = await res.json();
      if (json.code !== 0) throw new Error(json.message || '商品不存在');
      return json.data;
    }
    const p = SHOP_PRODUCTS.find((x) => x.id === id);
    if (!p) throw new Error('商品不存在');
    return p;
  }

  /* ---------------- 订单 ---------------- */
  /** 创建订单（模拟支付） */
  async function createOrder(payload) {
    if (await detectBackend()) {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (json.code !== 0) throw new Error(json.message || '下单失败');
      return json.data;
    }
    // ---- 模拟实现 ----
    const items = payload.items || [];
    if (!items.length) throw new Error('订单商品不能为空');
    const orderItems = [];
    let total = 0;
    for (const it of items) {
      const p = SHOP_PRODUCTS.find((x) => x.id === it.productId);
      if (!p) throw new Error(`商品不存在: ${it.productId}`);
      const quantity = Math.floor(Number(it.quantity));
      if (!quantity || quantity <= 0) throw new Error(`商品数量非法: ${it.productId}`);
      if (quantity > p.stock) throw new Error(`「${p.name}」库存不足`);
      orderItems.push({ productId: p.id, name: p.name, image: p.image, price: p.price, quantity, subtotal: p.price * quantity });
      total += p.price * quantity;
    }
    const now = new Date();
    const order = {
      id: mockGenOrderNo(),
      items: orderItems,
      total,
      customer: payload.customer || { name: '', phone: '', address: '' },
      status: '已支付',
      createdAt: now.toISOString(),
      paidAt: now.toISOString(),
    };
    const orders = mockGetOrders();
    orders.unshift(order);
    localStorage.setItem(LS_ORDERS, JSON.stringify(orders));
    return order;
  }

  /** 查询订单 */
  async function getOrder(id) {
    if (await detectBackend()) {
      const res = await fetch(`/api/orders/${id}`);
      const json = await res.json();
      if (json.code !== 0) throw new Error(json.message || '订单不存在');
      return json.data;
    }
    const o = mockGetOrders().find((x) => x.id === id);
    if (!o) throw new Error('订单不存在');
    return o;
  }

  /** 获取全部订单（个人中心） */
  async function getOrders() {
    if (await detectBackend()) {
      const res = await fetch('/api/orders');
      const json = await res.json();
      return json.code === 0 ? json.data : [];
    }
    return mockGetOrders();
  }

  /* ---------------- 用户（加分项） ---------------- */
  async function register(payload) {
    if (await detectBackend()) {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return res.json();
    }
    // 模拟：localStorage 持久化用户
    const users = JSON.parse(localStorage.getItem('cloud_users') || '[]');
    if (users.some((u) => u.username === payload.username)) {
      return { code: 409, message: '用户名已存在' };
    }
    const user = { id: `u${Date.now()}`, username: payload.username, password: payload.password };
    users.push(user);
    localStorage.setItem('cloud_users', JSON.stringify(users));
    return { code: 0, data: { id: user.id, username: user.username } };
  }

  async function login(payload) {
    if (await detectBackend()) {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return res.json();
    }
    const users = JSON.parse(localStorage.getItem('cloud_users') || '[]');
    const user = users.find((u) => u.username === payload.username && u.password === payload.password);
    if (!user) return { code: 401, message: '用户名或密码错误' };
    localStorage.setItem(LS_USER, JSON.stringify({ id: user.id, username: user.username }));
    return { code: 0, data: { token: 'mock-token', user: { id: user.id, username: user.username } } };
  }

  async function getCurrentUser() {
    if (await detectBackend()) {
      const res = await fetch('/api/auth/me', { headers: { Authorization: 'Bearer mock-token' } });
      const json = await res.json();
      return json.code === 0 ? json.data : null;
    }
    try { return JSON.parse(localStorage.getItem(LS_USER)); } catch { return null; }
  }

  function logout() {
    localStorage.removeItem(LS_USER);
  }

  /* ---------------- 后端模式查询（供 UI 显示） ---------------- */
  async function isBackendMode() {
    return detectBackend();
  }

  return {
    getProducts,
    getProduct,
    createOrder,
    getOrder,
    getOrders,
    register,
    login,
    getCurrentUser,
    logout,
    isBackendMode,
  };
})();
