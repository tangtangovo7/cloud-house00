/**
 * 云屋 CLOUD 商城 - 主应用
 * 视图：首页 / 商品列表(搜索·筛选·排序·分页) / 商品详情 / 下单 / 订单结果 / 个人中心
 * 购物车：侧拉式抽屉 + localStorage 状态管理
 */
const App = (() => {
  /* ================= 购物车状态管理 ================= */
  const Cart = {
    KEY: 'cloud_cart',
    items: [],
    init() {
      try { this.items = JSON.parse(localStorage.getItem(this.KEY)) || []; }
      catch { this.items = []; }
    },
    save() {
      localStorage.setItem(this.KEY, JSON.stringify(this.items));
      this.renderBadge();
      this.renderDrawer();
      document.dispatchEvent(new CustomEvent('cart:changed'));
    },
    get() { return this.items.map((i) => ({ ...i })); },
    add(productId, quantity = 1) {
      const exist = this.items.find((i) => i.productId === productId);
      if (exist) exist.quantity += quantity;
      else {
        const p = SHOP_PRODUCTS.find((x) => x.id === productId);
        this.items.push({ productId, name: p ? p.name : productId, image: p ? p.image : '', price: p ? p.price : 0, quantity });
      }
      this.save();
    },
    setQuantity(productId, quantity) {
      const exist = this.items.find((i) => i.productId === productId);
      if (!exist) return;
      if (quantity <= 0) this.remove(productId);
      else exist.quantity = quantity;
      this.save();
    },
    remove(productId) {
      this.items = this.items.filter((i) => i.productId !== productId);
      this.save();
    },
    clear() { this.items = []; this.save(); },
    totalCount() { return this.items.reduce((s, i) => s + i.quantity, 0); },
    totalPrice() { return this.items.reduce((s, i) => s + i.price * i.quantity, 0); },
    renderBadge() {
      const badge = document.getElementById('cartBadge');
      const n = this.totalCount();
      badge.textContent = n > 99 ? '99+' : n;
      badge.classList.toggle('show', n > 0);
    },
    renderDrawer() {
      const body = document.getElementById('cartBody');
      const footer = document.getElementById('cartFooter');
      if (!this.items.length) {
        body.innerHTML = `<div class="cart-empty"><span class="emoji">🛒</span><p>购物车还是空的</p><p style="font-size:0.85rem">去挑几件喜欢的商品吧～</p></div>`;
        footer.innerHTML = '';
        return;
      }
      body.innerHTML = this.items
        .map(
          (i) => `
          <div class="cart-item">
            <div class="ci-img"><img src="${i.image}" alt="${i.name}" /></div>
            <div class="ci-info">
              <div class="ci-name">${i.name}</div>
              <div class="ci-price">¥${i.price}</div>
              <div class="ci-sub">
                <div class="qty-stepper">
                  <button data-min="${i.productId}" aria-label="减少">−</button>
                  <input type="text" value="${i.quantity}" data-qty="${i.productId}" inputmode="numeric" />
                  <button data-plus="${i.productId}" aria-label="增加">+</button>
                </div>
                <span class="ci-subtotal">¥${(i.price * i.quantity).toFixed(0)}</span>
              </div>
            </div>
            <button class="ci-remove" data-remove="${i.productId}" title="移除">✕</button>
          </div>`
        )
        .join('');
      footer.innerHTML = `
        <div class="cart-total-row"><span>合计（${this.totalCount()} 件）</span><b>¥${this.totalPrice().toFixed(0)}</b></div>
        <div class="cart-actions">
          <button class="btn btn-outline" id="cartClear">清空购物车</button>
          <button class="btn btn-primary" id="cartCheckout">去结算</button>
        </div>`;
      // 事件绑定
      body.querySelectorAll('[data-min]').forEach((b) => b.addEventListener('click', () => this.setQuantity(b.dataset.min, (this.items.find((i) => i.productId === b.dataset.min) || {}).quantity - 1)));
      body.querySelectorAll('[data-plus]').forEach((b) => b.addEventListener('click', () => this.setQuantity(b.dataset.plus, (this.items.find((i) => i.productId === b.dataset.plus) || {}).quantity + 1)));
      body.querySelectorAll('[data-qty]').forEach((i) =>
        i.addEventListener('change', () => {
          const v = parseInt(i.value, 10);
          if (Number.isFinite(v) && v > 0) this.setQuantity(i.dataset.qty, v);
          else { i.value = (this.items.find((x) => x.productId === i.dataset.qty) || {}).quantity; }
        })
      );
      body.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', () => this.remove(b.dataset.remove)));
      document.getElementById('cartClear').addEventListener('click', () => {
        if (confirm('确定清空购物车吗？')) this.clear();
      });
      document.getElementById('cartCheckout').addEventListener('click', () => {
        this.closeDrawer();
        location.hash = '#/checkout';
      });
    },
    openDrawer() {
      document.getElementById('cartDrawer').classList.add('open');
      document.getElementById('cartOverlay').classList.add('open');
      this.renderDrawer();
    },
    closeDrawer() {
      document.getElementById('cartDrawer').classList.remove('open');
      document.getElementById('cartOverlay').classList.remove('open');
    },
  };

  /* ================= 工具函数 ================= */
  function money(n) { return `¥${Number(n).toFixed(0)}`; }
  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 2200);
  }

  /* ================= 视图渲染 ================= */
  const app = () => document.getElementById('app');

  function productCard(p) {
    return `
      <div class="product-card" data-id="${p.id}">
        <div class="pc-img"><img src="${p.image}" alt="${p.name}" loading="lazy" /></div>
        <div class="pc-body">
          <div class="pc-tags"><span class="tag cat">${escapeHtml(p.category)}</span>${(p.tags || []).slice(0, 2).map((t) => `<span class="tag">${escapeHtml(t)}</span>`).join('')}</div>
          <div class="pc-name" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</div>
          <div class="pc-desc">${escapeHtml(p.description.slice(0, 22))}…</div>
          <div class="pc-price-row">
            <div class="pc-price"><span class="cur">¥</span>${p.price}<span class="pc-origin">¥${p.originalPrice}</span></div>
            <button class="pc-add" data-add="${p.id}" title="加入购物车">＋</button>
          </div>
        </div>
      </div>`;
  }

  function bindProductEvents(root) {
    root.querySelectorAll('.product-card').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('[data-add]')) return;
        location.hash = `#/product/${card.dataset.id}`;
      });
      const addBtn = card.querySelector('[data-add]');
      if (addBtn) addBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        Cart.add(addBtn.dataset.add, 1);
        toast('已加入购物车 🛒');
      });
    });
  }

  /* ---------- 首页 ---------- */
  async function renderHome() {
    const data = await Api.getProducts({ pageSize: 60, sort: 'sales' });
    const products = data.list;
    const categories = data.categories;
    const catIcons = { '音频': '🎧', '桌面': '⌨️', '照明': '💡', '显示': '🖥️', '配件': '🔌', '家居': '🪑' };
    const hot = products.slice(0, 4);
    const featured = products.filter((p) => !hot.some((h) => h.id === p.id)).slice(0, 8);

    app().innerHTML = `
      <div class="view">
        <section class="hero">
          <div class="hero-text">
            <h1>发现新一代<br/>科技数码好物</h1>
            <p>云屋 CLOUD · 让日常科技触手可及</p>
            <a href="#/products" class="btn btn-primary">探索全部商品</a>
          </div>
          <div class="hero-emoji">☁️</div>
        </section>

        <div class="cat-bar">
          ${categories.map((c) => `<div class="cat-item" data-cat="${c}"><span class="cat-icon">${catIcons[c] || '📦'}</span><span class="cat-name">${c}</span><span class="cat-count">${products.filter((p) => p.category === c).length} 件</span></div>`).join('')}
        </div>

        <div class="section-title">🔥 热门推荐 <small>销量 Top ${hot.length}</small></div>
        <div class="grid">${hot.map(productCard).join('')}</div>

        <div style="height:2rem"></div>
        <div class="section-title">✨ 精选产品 <small>全部 ${products.length} 件商品</small><a class="section-more" href="#/products">查看全部 →</a></div>
        <div class="grid">${featured.map(productCard).join('')}</div>
      </div>`;

    app().querySelectorAll('.cat-item').forEach((el) =>
      el.addEventListener('click', () => { location.hash = `#/products?category=${encodeURIComponent(el.dataset.cat)}`; })
    );
    bindProductEvents(app());
  }

  /* ---------- 商品列表页 ---------- */
  async function renderProducts() {
    const qs = new URLSearchParams(location.hash.split('?')[1] || '');
    const state = {
      keyword: qs.get('keyword') || '',
      category: qs.get('category') || '',
      minPrice: qs.get('minPrice') || '',
      maxPrice: qs.get('maxPrice') || '',
      sort: qs.get('sort') || '',
      page: Number(qs.get('page')) || 1,
    };

    const data = await Api.getProducts({
      keyword: state.keyword,
      category: state.category,
      minPrice: state.minPrice || undefined,
      maxPrice: state.maxPrice || undefined,
      sort: state.sort || undefined,
      page: state.page,
      pageSize: 12,
    });
    const totalPages = Math.max(1, Math.ceil(data.total / 12));

    const hasFilter = state.category || state.minPrice || state.maxPrice || state.keyword;
    const filterSummary = [
      state.category && `分类：${state.category}`,
      state.keyword && `关键词：「${state.keyword}」`,
      (state.minPrice || state.maxPrice) && `价格：${state.minPrice || '不限'}~${state.maxPrice || '不限'} 元`,
    ].filter(Boolean).join(' · ');

    app().innerHTML = `
      <div class="view">
        <h1 class="view-title">全部商品</h1>
        <p class="view-sub">共 <b>${data.total}</b> 件商品，支持搜索、分类筛选与价格区间筛选</p>
        ${hasFilter ? `<div class="filter-summary">已筛选：${escapeHtml(filterSummary)}</div>` : ''}

        <div class="list-layout">
          <aside class="filter-panel">
            <div class="filter-title">筛选条件</div>
            <div class="filter-group">
              <h4>商品分类</h4>
              <div class="filter-options">
                <label class="filter-option"><input type="checkbox" data-cat="" ${!state.category ? 'checked' : ''} /> 全部</label>
                ${data.categories.map((c) => `<label class="filter-option"><input type="checkbox" data-cat="${c}" ${state.category === c ? 'checked' : ''} /> ${c}</label>`).join('')}
              </div>
            </div>
            <div class="filter-group">
              <h4>价格区间（元）</h4>
              <div class="price-inputs">
                <input type="number" id="minPrice" placeholder="最低" value="${state.minPrice}" min="0" />
                <span>—</span>
                <input type="number" id="maxPrice" placeholder="最高" value="${state.maxPrice}" min="0" />
              </div>
              <div class="price-range-labels"><span>¥0</span><span>¥1600</span></div>
            </div>
            <div class="filter-actions">
              <button class="btn btn-primary btn-sm" id="applyFilter">应用</button>
              <button class="btn btn-danger-outline btn-sm" id="resetFilter">重置</button>
            </div>
          </aside>

          <div class="list-content" style="flex:1">
            <div class="list-toolbar">
              <div class="count">共 <b>${data.total}</b> 件商品</div>
              <select class="sort-select" id="sortSelect">
                <option value="">推荐排序</option>
                <option value="sales" ${state.sort === 'sales' ? 'selected' : ''}>销量优先</option>
                <option value="priceAsc" ${state.sort === 'priceAsc' ? 'selected' : ''}>价格从低到高</option>
                <option value="priceDesc" ${state.sort === 'priceDesc' ? 'selected' : ''}>价格从高到低</option>
                <option value="rating" ${state.sort === 'rating' ? 'selected' : ''}>评分最高</option>
              </select>
            </div>
            ${data.list.length ? `<div class="grid">${data.list.map(productCard).join('')}</div>` : `<div class="empty-state"><span class="emoji">🔍</span><p>没有找到符合条件的商品</p><p style="font-size:0.85rem">试试调整筛选条件或搜索词</p><button class="btn btn-outline" id="emptyReset">重置筛选</button></div>`}
            <div class="pagination">
              ${Array.from({ length: totalPages }, (_, i) => i + 1)
                .map((p) => `<button class="${p === state.page ? 'active' : ''}" data-page="${p}">${p}</button>`)
                .join('')}
            </div>
          </div>
        </div>
      </div>`;

    // 分类勾选（互斥单选）
    app().querySelectorAll('[data-cat]').forEach((cb) =>
      cb.addEventListener('change', () => {
        app().querySelectorAll('[data-cat]').forEach((o) => { if (o !== cb) o.checked = false; });
        cb.checked = true;
      })
    );
    // 应用筛选
    document.getElementById('applyFilter').addEventListener('click', () => {
      const cat = app().querySelector('[data-cat]:checked');
      const params = new URLSearchParams();
      if (cat && cat.dataset.cat) params.set('category', cat.dataset.cat);
      const min = document.getElementById('minPrice').value;
      const max = document.getElementById('maxPrice').value;
      if (min) params.set('minPrice', min);
      if (max) params.set('maxPrice', max);
      params.set('sort', document.getElementById('sortSelect').value);
      params.set('page', 1);
      location.hash = `#/products?${params.toString()}`;
    });
    document.getElementById('resetFilter').addEventListener('click', () => { location.hash = '#/products'; });
    const emptyReset = document.getElementById('emptyReset');
    if (emptyReset) emptyReset.addEventListener('click', () => { location.hash = '#/products'; });
    // 排序
    document.getElementById('sortSelect').addEventListener('change', (e) => {
      const params = new URLSearchParams(location.hash.split('?')[1] || '');
      params.set('sort', e.target.value);
      params.set('page', 1);
      location.hash = `#/products?${params.toString()}`;
    });
    // 分页
    app().querySelectorAll('[data-page]').forEach((btn) =>
      btn.addEventListener('click', () => {
        const params = new URLSearchParams(location.hash.split('?')[1] || '');
        params.set('page', btn.dataset.page);
        location.hash = `#/products?${params.toString()}`;
      })
    );
    bindProductEvents(app());
  }

  /* ---------- 商品详情页 ---------- */
  async function renderProduct(id) {
    try {
      const p = await Api.getProduct(id);
      const stockState = p.stock <= 0 ? 'out' : p.stock <= 20 ? 'low' : 'ok';
      const stockText = p.stock <= 0 ? '暂时缺货' : p.stock <= 20 ? `仅剩 ${p.stock} 件` : `现货 ${p.stock} 件`;

      app().innerHTML = `
        <div class="view">
          <a href="#/products" style="color:var(--brand);font-size:0.9rem">← 返回商品列表</a>
          <div class="detail-layout" style="margin-top:1rem">
            <div class="detail-gallery">
              <div class="detail-main-img"><img src="${p.image}" alt="${escapeHtml(p.name)}" /></div>
              <div class="detail-thumbs">
                <img src="${p.image}" class="active" alt="主图" />
                <img src="${p.image}" alt="细节" />
                <img src="${p.image}" alt="场景" />
                <img src="${p.image}" alt="包装" />
              </div>
            </div>
            <div class="detail-info">
              <div class="detail-cat"><span class="tag cat">${escapeHtml(p.category)}</span>${(p.tags || []).map((t) => `<span class="tag" style="margin-left:0.35rem">${escapeHtml(t)}</span>`).join('')}</div>
              <h1 class="detail-name">${escapeHtml(p.name)}</h1>
              <div class="detail-price-row">
                <div class="detail-price"><span class="cur">¥</span>${p.price}</div>
                <div class="detail-origin">¥${p.originalPrice}</div>
              </div>
              <div class="detail-stock"><span class="stock-dot ${stockState}"></span>${stockText}</div>
              <p class="detail-desc">${escapeHtml(p.description)}</p>
              <div class="detail-specs">
                <h4>产品规格</h4>
                <ul>${(p.specs || []).map((s) => `<li>${escapeHtml(s)}</li>`).join('')}</ul>
              </div>
              <div class="qty-row">
                <span class="qty-label">数量</span>
                <div class="qty-stepper">
                  <button id="qtyMin">−</button>
                  <input type="text" id="qtyInput" value="1" inputmode="numeric" />
                  <button id="qtyPlus">+</button>
                </div>
              </div>
              <div class="detail-actions">
                <button class="btn btn-outline" id="detailCart">加入购物车</button>
                <button class="btn btn-primary" id="detailBuy" ${p.stock <= 0 ? 'disabled' : ''}>立即购买</button>
              </div>
            </div>
          </div>
        </div>`;

      const qtyInput = document.getElementById('qtyInput');
      const qtyMin = document.getElementById('qtyMin');
      const qtyPlus = document.getElementById('qtyPlus');
      let qty = 1;
      const updateQty = (v) => { qty = Math.min(p.stock, Math.max(1, v)); qtyInput.value = qty; };
      qtyMin.addEventListener('click', () => updateQty(qty - 1));
      qtyPlus.addEventListener('click', () => updateQty(qty + 1));
      qtyInput.addEventListener('change', () => updateQty(parseInt(qtyInput.value, 10) || 1));

      document.getElementById('detailCart').addEventListener('click', () => {
        if (p.stock <= 0) return toast('该商品暂时缺货');
        Cart.add(p.id, qty);
        toast(`已加入购物车 ${qty} 件 🛒`);
      });
      document.getElementById('detailBuy').addEventListener('click', () => {
        if (p.stock <= 0) return toast('该商品暂时缺货');
        Cart.add(p.id, qty);
        Cart.openDrawer();
      });
      document.querySelectorAll('.detail-thumbs img').forEach((t) =>
        t.addEventListener('click', () => {
          document.querySelectorAll('.detail-thumbs img').forEach((o) => o.classList.remove('active'));
          t.classList.add('active');
          document.querySelector('.detail-main-img img').src = t.src;
        })
      );
    } catch (e) {
      app().innerHTML = `<div class="empty-state"><span class="emoji">😕</span><p>${escapeHtml(e.message)}</p><a class="btn btn-primary" href="#/products">返回商城</a></div>`;
    }
  }

  /* ---------- 下单页 ---------- */
  function renderCheckout() {
    const cart = Cart.get();
    if (!cart.length) {
      app().innerHTML = `<div class="empty-state"><span class="emoji">🛒</span><p>购物车为空，无法结算</p><a class="btn btn-primary" href="#/products">去逛逛</a></div>`;
      return;
    }
    const total = Cart.totalPrice();
    app().innerHTML = `
      <div class="view">
        <h1 class="view-title">结算订单</h1>
        <p class="view-sub">填写收货信息并模拟支付，无需真实付款</p>
        <div class="checkout-layout">
          <form class="checkout-form" id="checkoutForm">
            <h3>收货信息</h3>
            <div class="form-group"><label>收货人姓名</label><input type="text" id="cusName" required placeholder="请输入姓名" /></div>
            <div class="form-group"><label>联系电话</label><input type="tel" id="cusPhone" required placeholder="请输入手机号" pattern="1\\d{10}" /></div>
            <div class="form-group"><label>收货地址</label><input type="text" id="cusAddress" required placeholder="请输入详细地址" /></div>
            <button type="submit" class="btn btn-primary btn-block">提交订单（模拟支付）</button>
          </form>
          <aside class="checkout-summary">
            <h3>订单摘要</h3>
            ${cart.map((i) => `<div class="cs-item"><span>${escapeHtml(i.name)} × ${i.quantity}</span><span>¥${i.price * i.quantity}</span></div>`).join('')}
            <div class="cs-total"><span>合计</span><b>¥${total}</b></div>
            <div class="pay-note">💳 本商城使用模拟支付，点击提交后订单即视为已支付，不产生真实扣款。</div>
          </aside>
        </div>
      </div>`;

    document.getElementById('checkoutForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = e.target.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = '提交中…';
      try {
        const order = await Api.createOrder({
          items: cart.map((c) => ({ productId: c.productId, quantity: c.quantity })),
          customer: {
            name: document.getElementById('cusName').value,
            phone: document.getElementById('cusPhone').value,
            address: document.getElementById('cusAddress').value,
          },
        });
        Cart.clear();
        location.hash = `#/order/${order.id}`;
      } catch (err) {
        toast(err.message || '下单失败，请重试');
        submitBtn.disabled = false;
        submitBtn.textContent = '提交订单（模拟支付）';
      }
    });
  }

  /* ---------- 订单结果页 ---------- */
  async function renderOrder(id) {
    try {
      const o = await Api.getOrder(id);
      const fmtTime = new Date(o.createdAt).toLocaleString('zh-CN', { hour12: false });
      app().innerHTML = `
        <div class="view">
          <div class="order-success">
            <div class="success-icon">✓</div>
            <h2>订单提交成功</h2>
            <p class="sub">模拟支付已完成，商品将尽快为你安排发货</p>
            <div class="order-meta">
              <div>订单编号<b>${o.id}</b></div>
              <div>创建时间<b>${fmtTime}</b></div>
              <div>订单状态<b>${o.status}</b></div>
            </div>
            <div class="order-items">
              <h3>商品信息</h3>
              ${o.items.map((i) => `
                <div class="oi-row">
                  <img src="${i.image}" alt="${escapeHtml(i.name)}" />
                  <span class="oi-name">${escapeHtml(i.name)}</span>
                  <span class="oi-qty">× ${i.quantity}</span>
                  <span class="oi-price">¥${i.price}</span>
                </div>`).join('')}
            </div>
            <div class="order-total"><span>订单总价</span><b>¥${o.total}</b></div>
            <div class="order-actions">
              <a class="btn btn-outline" href="#/orders">查看订单</a>
              <a class="btn btn-primary" href="#/">继续购物</a>
            </div>
          </div>
        </div>`;
    } catch (e) {
      app().innerHTML = `<div class="empty-state"><span class="emoji">😕</span><p>${escapeHtml(e.message)}</p><a class="btn btn-primary" href="#/">返回首页</a></div>`;
    }
  }

  /* ---------- 订单列表（个人中心） ---------- */
  async function renderOrders() {
    const orders = await Api.getOrders();
    app().innerHTML = `
      <div class="view">
        <h1 class="view-title">我的订单</h1>
        <p class="view-sub">共 ${orders.length} 笔订单</p>
        ${orders.length ? orders.map((o) => `
          <div class="checkout-summary" style="position:static;margin-bottom:1rem">
            <div class="order-meta" style="justify-content:flex-start;gap:1.5rem;margin-bottom:1rem">
              <div>订单编号<b>${o.id}</b></div>
              <div>状态<b>${o.status}</b></div>
              <div>时间<b>${new Date(o.createdAt).toLocaleString('zh-CN', { hour12: false })}</b></div>
            </div>
            ${o.items.map((i) => `<div class="cs-item"><span>${escapeHtml(i.name)} × ${i.quantity}</span><span>¥${i.price * i.quantity}</span></div>`).join('')}
            <div class="cs-total"><span>订单总价</span><b>¥${o.total}</b></div>
            <div style="margin-top:0.75rem"><a class="btn btn-outline btn-sm" href="#/order/${o.id}">查看详情</a></div>
          </div>`).join('') : `<div class="empty-state"><span class="emoji">📋</span><p>还没有订单</p><a class="btn btn-primary" href="#/products">去下单</a></div>`}
      </div>`;
  }

  /* ---------- 用户系统（加分项） ---------- */
  function openAuth(tab = 'login') {
    const overlay = document.getElementById('authOverlay');
    overlay.classList.add('open');
    switchTab(tab);
  }
  function closeAuth() { document.getElementById('authOverlay').classList.remove('open'); }

  function switchTab(tab) {
    document.querySelectorAll('.auth-tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
    document.getElementById('authTitle').textContent = tab === 'login' ? '登录' : '注册';
    document.getElementById('authSubmit').textContent = tab === 'login' ? '登录' : '注册并登录';
    document.getElementById('authStatus').textContent = '';
  }

  async function updateUserBtn() {
    const btn = document.getElementById('userBtn');
    const user = await Api.getCurrentUser();
    if (user) {
      btn.title = `${user.username}（点击查看订单）`;
      btn.addEventListener('click', () => { location.hash = '#/orders'; });
      btn.textContent = '📦';
    } else {
      btn.title = '登录 / 注册';
      btn.addEventListener('click', () => openAuth());
      btn.textContent = '👤';
    }
  }

  /* ================= 路由 ================= */
  async function router() {
    const hash = location.hash || '#/';
    try {
      if (hash === '#/' || hash === '#') await renderHome();
      else if (hash.startsWith('#/products')) await renderProducts();
      else if (hash.startsWith('#/product/')) await renderProduct(hash.split('/')[2]);
      else if (hash === '#/checkout') renderCheckout();
      else if (hash.startsWith('#/order/')) await renderOrder(hash.split('/')[2]);
      else if (hash === '#/orders') await renderOrders();
      else { location.hash = '#/'; return; }
    } catch (e) {
      console.error('[router]', e);
      app().innerHTML = `<div class="empty-state"><span class="emoji">⚠️</span><p>页面加载失败：${escapeHtml(e.message)}</p><a class="btn btn-primary" href="#/">返回首页</a></div>`;
    }
    // 高亮导航
    document.querySelectorAll('.main-nav a').forEach((a) => {
      const nav = a.dataset.nav;
      const active = (nav === 'home' && (hash === '#' || hash === '#/')) ||
        (nav === 'products' && hash.startsWith('#/products')) ||
        (nav.startsWith('cat-') && hash.includes(`category=${encodeURIComponent(a.textContent)}`));
      a.classList.toggle('active', active);
    });
    window.scrollTo({ top: 0 });
  }

  /* ================= 初始化 ================= */
  async function init() {
    Cart.init();
    Cart.renderBadge();

    // 顶部搜索
    const doSearch = () => {
      const kw = document.getElementById('globalSearch').value.trim();
      if (!kw) { toast('请输入搜索关键词'); return; }
      location.hash = `#/products?keyword=${encodeURIComponent(kw)}`;
    };
    document.getElementById('globalSearchBtn').addEventListener('click', doSearch);
    document.getElementById('globalSearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });

    // 购物车抽屉
    document.getElementById('cartBtn').addEventListener('click', () => Cart.openDrawer());
    document.getElementById('cartClose').addEventListener('click', () => Cart.closeDrawer());
    document.getElementById('cartOverlay').addEventListener('click', () => Cart.closeDrawer());

    // 移动端菜单
    document.getElementById('navToggle').addEventListener('click', () => {
      document.getElementById('mainNav').classList.toggle('open');
    });

    // 登录弹窗
    document.getElementById('userBtn').addEventListener('click', () => openAuth());
    document.getElementById('authClose').addEventListener('click', closeAuth);
    document.getElementById('authOverlay').addEventListener('click', (e) => { if (e.target === e.currentTarget) closeAuth(); });
    document.querySelectorAll('.auth-tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));
    document.getElementById('authForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('authUsername').value.trim();
      const password = document.getElementById('authPassword').value;
      const isLogin = document.querySelector('.auth-tab.active').dataset.tab === 'login';
      const status = document.getElementById('authStatus');
      const res = isLogin ? await Api.login({ username, password }) : await Api.register({ username, password });
      if (res.code === 0) {
        if (!isLogin) await Api.login({ username, password });
        status.textContent = isLogin ? '登录成功！' : '注册成功，已自动登录！';
        status.className = 'auth-status ok';
        setTimeout(() => { closeAuth(); updateUserBtn(); toast('欢迎回来，' + username); }, 600);
      } else {
        status.textContent = res.message || '操作失败';
        status.className = 'auth-status err';
      }
    });

    // AI Agent 面板
    const agentFab = document.getElementById('agentFab');
    const agentPanel = document.getElementById('agentPanel');
    agentFab.addEventListener('click', () => {
      agentPanel.classList.toggle('open');
      if (agentPanel.classList.contains('open')) Agent.restoreHistory();
    });
    document.getElementById('agentClose').addEventListener('click', () => agentPanel.classList.remove('open'));

    const quick = document.getElementById('agentQuick');
    const chips = ['🎧 500 元以内的耳机', '⌨️ 推荐 1000 元以内键盘', '💡 便宜的台灯', '🛒 看看购物车', '🤖 帮我买刚才推荐的那款'];
    quick.innerHTML = chips.map((c) => `<button class="chip">${c}</button>`).join('');
    quick.querySelectorAll('.chip').forEach((c) =>
      c.addEventListener('click', () => {
        document.getElementById('agentInput').value = c.textContent.replace(/^[^\u4e00-\u9fa5a-zA-Z0-9]+/, '');
        doAgentSend();
      })
    );

    const doAgentSend = () => {
      const input = document.getElementById('agentInput');
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      Agent.send(text);
    };
    document.getElementById('agentSend').addEventListener('click', doAgentSend);
    document.getElementById('agentInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') doAgentSend(); });

    // Agent 写入操作完成后刷新购物车 UI
    document.addEventListener('agent:cart-updated', () => { Cart.renderBadge(); });
    document.addEventListener('agent:order-created', (e) => {
      Cart.renderBadge();
      setTimeout(() => { location.hash = `#/order/${e.detail.orderId}`; }, 1600);
    });
    // 富消息内按钮
    document.getElementById('agentBody').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const id = btn.dataset.id;
      if (btn.dataset.act === 'detail') {
        location.hash = `#/product/${id}`;
      } else if (btn.dataset.act === 'add') {
        Cart.add(id, 1);
        toast('已加入购物车 🛒');
        document.dispatchEvent(new CustomEvent('agent:cart-updated'));
      }
    });

    // 初始路由与导航高亮
    await updateUserBtn();
    window.addEventListener('hashchange', () => {
      document.getElementById('mainNav').classList.remove('open');
      router();
    });
    await router();
  }

  return { init };
})();

document.addEventListener('DOMContentLoaded', () => App.init());
