/**
 * 云屋 CLOUD 商城 - AI 购物助手 Agent
 * ------------------------------------------------------------------
 * 能力分层（对应考核 9.1 ~ 9.8）：
 *  基础层  对话 / searchProducts 查询工具 / 多轮上下文
 *  进阶层  addToCart / updateCartItem / removeFromCart / getCart / createOrder
 *          （写入操作执行前必须向用户确认）、多步规划与约束求解、执行步骤面板
 *  高阶层  歧义澄清、超范围拒答、防提示词注入、异常重试、流式打字机、
 *          会话持久化、商品卡片富消息、上下文裁剪
 *  挑战层  在 README 中附 10+ 条测试用例与调用链路（Trace）说明
 * ------------------------------------------------------------------
 * 实现说明：本环境未接入外部大模型服务，Agent 采用「意图解析 + 工具调用 +
 * 多轮状态管理」的规则引擎实现，所有回答均基于商城真实商品数据（SHOP_PRODUCTS
 * 或后端 API），不凭模型记忆编造价格与库存。
 */
const Agent = (() => {
  /* ================= 状态 ================= */
  const LS_HISTORY = 'cloud_agent_history';
  let history = loadHistory(); // [{role:'user'|'assistant', text, rich}]
  let cartCache = []; // 当前购物车快照
  let lastRecommend = null; // 上一轮推荐的商品列表（用于"更便宜/更贵"上下文）
  let lastIntent = null; // 上一轮意图
  let pendingConfirm = null; // 待用户确认的写入操作 {type, payload, message}

  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(LS_HISTORY)) || []; }
    catch { return []; }
  }
  function saveHistory() {
    // 上下文裁剪：最多保留最近 20 条
    const trimmed = history.slice(-20);
    history = trimmed;
    try { localStorage.setItem(LS_HISTORY, JSON.stringify(trimmed)); } catch {}
  }

  /* ================= 工具注册表 ================= */
  const tools = {
    /** 商品查询工具：keyword / category / minPrice / maxPrice / sort */
    searchProducts: async ({ keyword = '', category = '', minPrice, maxPrice, sort } = {}) => {
      const params = { pageSize: 60 };
      if (keyword) params.keyword = keyword;
      if (category) params.category = category;
      if (minPrice !== undefined && minPrice !== null) params.minPrice = minPrice;
      if (maxPrice !== undefined && maxPrice !== null) params.maxPrice = maxPrice;
      if (sort) params.sort = sort;
      const data = await Api.getProducts(params);
      return { list: data.list, total: data.total };
    },

    /** 获取商品详情 */
    getProduct: async (id) => {
      return await Api.getProduct(id);
    },

    /** 查询当前购物车 */
    getCart: async () => {
      const cart = Cart.get();
      cartCache = cart;
      return cart;
    },

    /** 加入购物车（写入类，需确认） */
    addToCart: async ({ productId, quantity = 1 }) => {
      const product = await Api.getProduct(productId);
      if (!product) throw new Error('商品不存在');
      if (quantity <= 0) throw new Error('数量必须为正整数');
      if (quantity > product.stock) throw new Error(`「${product.name}」库存仅剩 ${product.stock} 件`);
      Cart.add(productId, quantity);
      const cart = Cart.get();
      cartCache = cart;
      return { product, quantity, cart };
    },

    /** 修改购物车数量（写入类，需确认） */
    updateCartItem: async ({ productId, quantity }) => {
      if (quantity < 0) throw new Error('数量不能为负数');
      const product = await Api.getProduct(productId).catch(() => null);
      if (product && quantity > product.stock) throw new Error(`「${product.name}」库存仅剩 ${product.stock} 件`);
      Cart.setQuantity(productId, quantity);
      const cart = Cart.get();
      cartCache = cart;
      return { productId, quantity, cart };
    },

    /** 移除购物车商品（写入类，需确认） */
    removeFromCart: async ({ productId }) => {
      Cart.remove(productId);
      const cart = Cart.get();
      cartCache = cart;
      return { productId, cart };
    },

    /** 创建订单（写入类，需确认，模拟支付） */
    createOrder: async ({ customer = {} } = {}) => {
      const cart = Cart.get();
      if (!cart.length) throw new Error('购物车为空，无法下单');
      const order = await Api.createOrder({
        items: cart.map((c) => ({ productId: c.productId, quantity: c.quantity })),
        customer,
      });
      Cart.clear();
      cartCache = [];
      return order;
    },
  };

  /* ================= 意图解析 ================= */
  /** 从文本中提取预算数字 */
  function extractBudget(text) {
    const nums = [];
    const re = /(\d{2,5})\s*元|(\d{2,5})\s*块钱|(\d{2,5})/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      const v = Number(m[1] || m[2] || m[3]);
      if (v >= 20 && v <= 20000) nums.push(v);
    }
    return nums;
  }

  const CATEGORY_KEYWORDS = {
    '音频': ['耳机', '耳麦', '头戴', '入耳', '降噪耳机', '音箱', '音响', '喇叭', '扬声器'],
    '桌面': ['键盘', '机械键盘', '鼠标', '桌面', '外设', '键鼠'],
    '照明': ['台灯', '落地灯', '灯', '照明', '氛围灯'],
    '显示': ['显示器', '屏幕', '显示屏'],
    '配件': ['充电器', '支架', '鼠标垫', '扩展坞', '摄像头', '充电', '氮化镓'],
    '家居': ['升降桌', '椅子', '办公椅', '书桌', '家居'],
  };

  /** 提取商品类型关键词 */
  function extractCategory(text) {
    for (const [cat, words] of Object.entries(CATEGORY_KEYWORDS)) {
      if (words.some((w) => text.includes(w))) return cat;
    }
    return null;
  }

  /** 提取动作关键词 */
  function detectAction(text) {
    if (/买|下单|结账|结算|支付/.test(text)) return 'buy';
    if (/加(入)?(购物)?车|添加到购物车/.test(text)) return 'add';
    if (/删(除)?|移除|去掉/.test(text) && (/购物车|商品|从.*(车|购物)/.test(text) || /(耳机|键盘|鼠标|音箱|台灯|显示器|充电|支架|扩展坞|升降桌|椅子|Buds|Air|Key|Mouse|Glow|Lamp|View|Cam|Charge|Stand|Pad|Hub|Desk|Chair)/.test(text))) return 'remove';
    if (/便宜|降价|低一点|再低|更便宜|价格低/.test(text)) return 'cheaper';
    if (/贵一点|更好|更高端|价格高/.test(text)) return 'expensive';
    if (/购物车|看看(我)?(的)?(购物)?车/.test(text)) return 'cart';
    if (/推荐|有什么|看看|找(个|一下|点)?/.test(text)) return 'recommend';
    if (/搜索|查(一)?下|查找/.test(text)) return 'search';
    if (/你好|您好|hi|hello|嗨/.test(text)) return 'greeting';
    return 'query';
  }

  /** 防提示词注入检测 */
  function detectInjection(text) {
    const patterns = [
      /忽略(你)?(之前|以前|上面)?(所有|全部)?(的)?(指令|指示|规则|设定|system prompt)/,
      /(按|以)?1\s*元(钱)?(的?)?(价格)?(卖|出售|成交|结算|给)/,
      /免(费)?(送|卖)/,
      /无视.*规则/,
      /把所有商品/,
      /system\s*prompt/i,
      /你(是)?(一个)?(免费|开源|没有限制)/,
      /解除.*限制/,
      /prompt\s*injection/i,
    ];
    return patterns.some((p) => p.test(text));
  }

  /** 超范围检测：与购物无关的话题 */
  function detectOffTopic(text) {
    const topicKeywords = [
      '代码', '编程', '写个', '写一段', 'python', 'javascript', '算法', '数学',
      '天气', '新闻', '电影', '音乐推荐(?!.*商城)', '历史', '政治', '医学', '医疗',
      '写诗', '故事', '小说', '翻译', '论文', '作文', '作业',
      '你是谁做的', '你的模型', '你的开发商', '介绍一下你自己',
    ];
    // 排除包含商城/商品意图的语句
    if (/耳机|键盘|鼠标|音箱|台灯|显示器|充电器|支架|扩展坞|升降桌|椅子|购物|商城|商品|买|价格|预算/.test(text)) {
      return false;
    }
    return topicKeywords.some((k) => text.includes(k));
  }

  /* ================= 约束求解 ================= */
  /**
   * 多步规划示例：预算内组合（耳机 + 键盘 + 剩余配件）
   * 返回最优组合方案
   */
  async function planCombo({ budget, needHeadphones = true, needKeyboard = true, preferSameBrand = true }) {
    const steps = [];
    // 1. 查询耳机
    steps.push({ phase: '思考', detail: `拆解需求：预算 ${budget} 元，需要一副耳机 + 一把键盘，若有剩余再配配件` });
    const headList = (await tools.searchProducts({ category: '音频', sort: 'priceAsc' })).list
      .filter((p) => p.name.includes('耳机'));
    steps.push({ phase: '调用', tool: 'searchProducts', args: { category: '音频' }, result: `返回 ${headList.length} 款耳机` });
    // 2. 查询键盘
    const keyList = (await tools.searchProducts({ category: '桌面', sort: 'priceAsc' })).list
      .filter((p) => p.name.includes('键盘'));
    steps.push({ phase: '调用', tool: 'searchProducts', args: { category: '桌面' }, result: `返回 ${keyList.length} 款键盘` });

    // 3. 求组合：耳机 + 键盘 <= budget
    let best = null;
    for (const h of headList) {
      for (const k of keyList) {
        if (h.price + k.price <= budget) {
          const remain = budget - h.price - k.price;
          const combo = { head: h, key: k, total: h.price + k.price, remain };
          if (!best || (combo.remain < best.remain && combo.total >= best.total)) {
            best = combo;
          } else if (!best || combo.remain > best.remain) {
            // 优先总价高、剩余少
            if (combo.total > best.total) best = combo;
          }
        }
      }
    }
    if (!best) {
      steps.push({ phase: '约束求解', detail: '无耳机+键盘组合满足预算' });
      return { steps, best: null };
    }
    steps.push({
      phase: '约束求解',
      detail: `组合 ${best.head.name}(${best.head.price}) + ${best.key.name}(${best.key.price}) = ${best.total} 元，剩余 ${best.remain} 元`,
    });

    // 4. 剩余预算尝试配件
    let acc = null;
    if (best.remain > 0) {
      const accList = (await tools.searchProducts({ category: '配件', sort: 'priceAsc' })).list;
      steps.push({ phase: '调用', tool: 'searchProducts', args: { category: '配件' }, result: `返回 ${accList.length} 款配件` });
      acc = accList.filter((p) => p.price <= best.remain)[0] || null;
      if (acc) {
        steps.push({ phase: '约束求解', detail: `剩余 ${best.remain} 元可搭配 ${acc.name}(${acc.price})，最终合计 ${best.total + acc.price} 元，还剩 ${best.remain - acc.price} 元` });
        best.accessory = acc;
      }
    }
    return { steps, best };
  }

  /* ================= 回复生成 ================= */
  function money(n) { return `¥${n}`; }

  function productRichHtml(p) {
    return `
      <div class="product-rich" data-id="${p.id}">
        <div class="pr-img"><img src="${p.image}" alt="${p.name}" loading="lazy" /></div>
        <div class="pr-body">
          <div class="pr-name">${p.name}</div>
          <div class="pr-price"><span class="cur">¥</span>${p.price}
            <span style="color:#6b7280;font-size:0.78rem;text-decoration:line-through;margin-left:0.3rem;font-weight:400;">¥${p.originalPrice}</span>
          </div>
          <div class="pr-actions">
            <button class="btn btn-primary btn-sm" data-act="detail" data-id="${p.id}">查看详情</button>
            <button class="btn btn-outline btn-sm" data-act="add" data-id="${p.id}">加入购物车</button>
          </div>
        </div>
      </div>`;
  }

  /* ================= 流式输出 ================= */
  function streamText(el, text, onDone) {
    const target = el;
    target.classList.add('streaming');
    let i = 0;
    const speed = 12; // 每字符间隔 ms
    function tick() {
      if (i <= text.length) {
        target.innerHTML = escapeHtml(text.slice(0, i)) + '<span class="typing-caret">▍</span>';
        i += 1;
        const gap = text[i] === '\n' ? speed * 4 : speed;
        setTimeout(tick, gap);
      } else {
        target.innerHTML = escapeHtml(text);
        target.classList.remove('streaming');
        if (onDone) onDone();
      }
    }
    tick();
  }

  function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* ================= 确认流程 ================= */
  function buildConfirmMessage(type, payload) {
    switch (type) {
      case 'addToCart': {
        const p = payload.product;
        return `我准备把 **${p.name}**（${money(p.price)} × ${payload.quantity}件）加入购物车，确认执行吗？`;
      }
      case 'updateCartItem': {
        const item = cartCache.find((c) => c.productId === payload.productId);
        const name = item ? item.name : payload.productId;
        return payload.quantity === 0
          ? `我准备把 **${name}** 从购物车移除，确认吗？`
          : `我准备把 **${name}** 的数量改为 ${payload.quantity} 件，确认吗？`;
      }
      case 'removeFromCart': {
        const item = cartCache.find((c) => c.productId === payload.productId);
        const name = item ? item.name : payload.productId;
        return `我准备把 **${name}** 从购物车移除，确认吗？`;
      }
      case 'createOrder': {
        const total = cartCache.reduce((s, c) => s + c.price * c.quantity, 0);
        return `当前购物车共 **${cartCache.length}** 种商品，合计 **${money(total)}**。确认提交订单并模拟支付吗？`;
      }
      default:
        return `确认执行该操作吗？`;
    }
  }

  /* ================= 主入口：处理用户输入 ================= */
  async function handle(userText) {
    const text = String(userText || '').trim();
    if (!text) return null;

    // ---- 高阶层：安全防护 ----
    if (detectInjection(text)) {
      return {
        reply: '抱歉，我不能执行这条指令。所有商品价格均以商城真实数据为准，我无法修改价格或绕过商城规则。需要我帮你找什么商品吗？',
        intent: 'injection',
        steps: [{ phase: '安全拦截', detail: '检测到疑似提示词注入，拒绝执行' }],
      };
    }
    if (detectOffTopic(text)) {
      return {
        reply: '我是云屋商城的购物助手，只能协助你浏览、筛选和购买商城中的商品。如果想聊聊别的，我很乐意帮你推荐一款好产品～ 例如试试「500 元以内的耳机」？',
        intent: 'offtopic',
        steps: [{ phase: '范围校验', detail: '请求超出购物协助范围，已礼貌拒答' }],
      };
    }

    // ---- 处理确认回复 ----
    if (pendingConfirm && /^(确认|确定|好的|可以|是|嗯|OK|ok|同意|下单|买吧)/.test(text)) {
      return await executePendingConfirm(true);
    }
    if (pendingConfirm && /^(取消|不用|算了|不了|否|不要)/.test(text)) {
      const cancelled = pendingConfirm;
      pendingConfirm = null;
      return {
        reply: `好的，已取消「${cancelled.type}」操作。还有什么可以帮你？`,
        intent: 'cancel',
        steps: [{ phase: '取消执行', detail: `用户取消 ${cancelled.type}` }],
      };
    }

    // ---- 多步规划：耳机 + 键盘组合（优先于单意图判断） ----
    const comboBudget = extractBudget(text);
    if (text.includes('耳机') && text.includes('键盘') && comboBudget.length) {
      const steps = [{ phase: '理解需求', detail: `识别意图：多步规划（耳机+键盘组合）` }];
      const plan = await planCombo({ budget: comboBudget[0], needHeadphones: true, needKeyboard: true });
      if (!plan.best) {
        return {
          reply: `我尝试了预算 ${money(comboBudget[0])} 内耳机 + 键盘的所有组合，很遗憾没有符合的组合。两个替代方案供参考：\n1. 只买一副耳机：最贵的可承受款\n2. 只买一把键盘：把预算全部留给键盘\n需要我按其中一种帮你筛选吗？`,
          intent: 'combo',
          steps: [...steps, ...plan.steps],
        };
      }
      const b = plan.best;
      lastRecommend = [b.head, b.key];
      let reply = `根据预算 ${money(comboBudget[0])}，我帮你规划了最优组合：\n`;
      reply += `🎧 **${b.head.name}** ${money(b.head.price)}\n⌨️ **${b.key.name}** ${money(b.key.price)}\n`;
      if (b.accessory) {
        reply += `🧩 搭配 **${b.accessory.name}** ${money(b.accessory.price)}\n`;
        reply += `合计 **${money(b.total + b.accessory.price)}**，预算剩余 ${money(b.remain - b.accessory.price)} 元。\n`;
      } else {
        reply += `合计 **${money(b.total)}**，预算剩余 ${money(b.remain)} 元。\n`;
      }
      reply += `是否要我帮你把这几件加入购物车？`;
      return { reply, intent: 'combo', steps: [...steps, ...plan.steps], rich: productRichHtml(b.head) + productRichHtml(b.key) + (b.accessory ? productRichHtml(b.accessory) : '') };
    }

    // ---- 意图解析 ----
    const intent = detectAction(text);
    const steps = [];
    steps.push({ phase: '理解需求', detail: `识别意图：${intent}` });

    // 购物车查询
    if (intent === 'cart') {
      const cart = await tools.getCart();
      steps.push({ phase: '调用工具', tool: 'getCart', args: {}, result: `购物车 ${cart.length} 种商品` });
      if (!cart.length) {
        return { reply: '你的购物车还是空的，看看首页的精选商品？或者告诉我预算和想要的品类，我来帮你挑。', intent, steps };
      }
      const lines = cart.map((c) => `· ${c.name} × ${c.quantity} = ${money(c.price * c.quantity)}`);
      const total = cart.reduce((s, c) => s + c.price * c.quantity, 0);
      return {
        reply: `你的购物车有 ${cart.length} 种商品：\n${lines.join('\n')}\n合计 **${money(total)}**。\n需要我帮你提交订单吗？回复「下单」即可。`,
        intent,
        steps,
      };
    }

    // 删除购物车商品
    if (intent === 'remove') {
      const cart = await tools.getCart();
      const nameMatch = text.match(/(?:删除|移除|去掉)(.+)/);
      const target = nameMatch ? nameMatch[1].trim() : null;
      if (!target) {
        return {
          reply: '你想移除购物车里的哪个商品呢？告诉我商品名即可，例如「删除耳机」。',
          intent,
          steps: [...steps, { phase: '歧义澄清', detail: '删除目标不明确，追问商品名' }],
        };
      }
      const item = cart.find((c) => c.name.includes(target) || c.productId === target);
      if (!item) {
        return {
          reply: `购物车里没有找到包含「${target}」的商品。当前购物车：${cart.map((c) => c.name).join('、') || '（空）'}`,
          intent,
          steps: [...steps, { phase: '调用工具', tool: 'getCart', args: {}, result: '未命中删除目标' }],
        };
      }
      pendingConfirm = { type: 'removeFromCart', payload: { productId: item.productId } };
      return {
        reply: buildConfirmMessage('removeFromCart', { productId: item.productId }),
        intent,
        steps: [...steps, { phase: '待确认', detail: `准备移除 ${item.name}` }],
        pending: true,
      };
    }

    // 加购
    if (intent === 'add') {
      const nameMatch = text.match(/(?:把|将)?(.+?)(?:加(?:入)?(?:购物)?车|添加到购物车)/);
      const target = (nameMatch ? nameMatch[1] : '').replace(/^(帮我|请|麻烦)/, '').trim();
      if (!target) {
        return {
          reply: '好的，你想把哪个商品加入购物车？告诉我商品名或直接发商品链接给我。',
          intent,
          steps: [...steps, { phase: '歧义澄清', detail: '加购目标不明确，追问商品名' }],
        };
      }
      // 优先匹配上一轮推荐
      let product = null;
      if (lastRecommend) {
        product = lastRecommend.find((p) => target.includes(p.name.slice(-6)) || p.name.includes(target) || target.includes(p.name.slice(0, 6)));
      }
      if (!product) {
        const data = await tools.searchProducts({ keyword: target });
        product = data.list[0] || null;
      }
      if (!product) {
        return {
          reply: `商城暂时没有找到「${target}」相关的商品，换个关键词试试？例如「耳机」「键盘」「台灯」。`,
          intent,
          steps: [...steps, { phase: '调用工具', tool: 'searchProducts', args: { keyword: target }, result: '0 条结果' }],
        };
      }
      const qtyMatch = text.match(/(\d+)\s*件/);
      const quantity = qtyMatch ? Number(qtyMatch[1]) : 1;
      pendingConfirm = { type: 'addToCart', payload: { productId: product.id, quantity, product } };
      return {
        reply: buildConfirmMessage('addToCart', { ...pendingConfirm.payload, product }),
        intent,
        steps: [...steps, { phase: '调用工具', tool: 'searchProducts', args: { keyword: target }, result: `命中 ${product.name}` }, { phase: '待确认', detail: `加入购物车：${product.name} × ${quantity}` }],
        pending: true,
        rich: productRichHtml(product),
      };
    }

    // 购买 / 下单
    if (intent === 'buy') {
      const cart = await tools.getCart();
      if (!cart.length) {
        // 尝试直接购买推荐商品
        if (lastRecommend && lastRecommend.length) {
          const target = text.replace(/买|下单|结账|结算|支付/g, '').trim();
          let product = null;
          if (target) {
            const data = await tools.searchProducts({ keyword: target });
            product = data.list[0] || null;
          } else {
            product = lastRecommend[0];
          }
          if (product) {
            pendingConfirm = { type: 'addToCart', payload: { productId: product.id, quantity: 1, product } };
            return {
              reply: `购物车目前是空的。你提到想买 **${product.name}**（${money(product.price)}），我先把它加入购物车，确认吗？`,
              intent,
              steps: [...steps, { phase: '调用工具', tool: 'searchProducts', args: {}, result: `定位到 ${product.name}` }, { phase: '待确认', detail: '购物车为空，先加购再下单' }],
              pending: true,
              rich: productRichHtml(product),
            };
          }
        }
        return {
          reply: '你的购物车是空的，先去挑选商品吧～ 可以告诉我预算和品类，我帮你推荐，比如「500 元以内的降噪耳机」。',
          intent,
          steps: [...steps, { phase: '调用工具', tool: 'getCart', args: {}, result: '购物车为空' }],
        };
      }
      pendingConfirm = { type: 'createOrder', payload: {} };
      return {
        reply: buildConfirmMessage('createOrder', {}),
        intent,
        steps: [...steps, { phase: '调用工具', tool: 'getCart', args: {}, result: `${cart.length} 种商品` }, { phase: '待确认', detail: '模拟支付前需用户确认' }],
        pending: true,
      };
    }

    // 更便宜 / 更贵（多轮上下文）
    if (intent === 'cheaper' || intent === 'expensive') {
      if (!lastRecommend || !lastRecommend.length) {
        return {
          reply: '刚才我还没有推荐过商品。你可以告诉我预算和想要的品类，我来推荐，之后我就能帮你对比「更便宜/更好」的选项啦。',
          intent,
          steps: [...steps, { phase: '上下文检查', detail: '无上一轮推荐，无法比较' }],
        };
      }
      const prev = lastRecommend[0];
      const data = await tools.searchProducts({ category: prev.category, sort: intent === 'cheaper' ? 'priceAsc' : 'priceDesc' });
      const target = intent === 'cheaper'
        ? data.list.filter((p) => p.price < prev.price)
        : data.list.filter((p) => p.price > prev.price);
      steps.push({
        phase: '调用工具',
        tool: 'searchProducts',
        args: { category: prev.category, sort: intent === 'cheaper' ? 'priceAsc' : 'priceDesc' },
        result: `${prev.category} 类共 ${data.total} 款，取比上一款更${intent === 'cheaper' ? '便宜' : '好'}的`,
      });
      if (!target.length) {
        return {
          reply: `在 ${prev.category} 品类里，暂时没有比 ${prev.name}（${money(prev.price)}）更${intent === 'cheaper' ? '便宜' : '贵'}的商品了。`,
          intent,
          steps,
        };
      }
      const p = target[0];
      lastRecommend = [p];
      return {
        reply: `当然可以！上一款是 **${prev.name}**（${money(prev.price)}）。更${intent === 'cheaper' ? '便宜' : '好'}的推荐：\n**${p.name}**（${money(p.price)}）${p.tags ? '· ' + p.tags.join('/') : ''}\n${p.description}\n要不要加入购物车？或者再看看其他选项？`,
        intent,
        steps,
        rich: productRichHtml(p),
      };
    }

    // 推荐 / 搜索 / 查询（核心）
    // 提取预算与品类
    const budgets = extractBudget(text);
    const budget = budgets.length ? Math.min(...budgets) : null; // 取最小值作为预算上限
    const category = extractCategory(text);
    steps.push({ phase: '提取约束', detail: `品类：${category || '不限'}，预算：${budget ? `≤${money(budget)}` : '不限'}` });

    // 普通推荐 / 搜索
    const sort = intent === 'expensive' ? 'priceDesc' : undefined;
    const data = await tools.searchProducts({
      keyword: category ? undefined : extractSearchWord(text),
      category: category || undefined,
      maxPrice: budget || undefined,
      sort,
    });
    steps.push({
      phase: '调用工具',
      tool: 'searchProducts',
      args: { category: category || '', maxPrice: budget || '', keyword: category ? '' : extractSearchWord(text) },
      result: `共 ${data.total} 件符合条件`,
    });

    if (!data.list.length) {
      return {
        reply: `很抱歉，在商城真实数据中没有找到符合条件（${category || ''}${budget ? ` 预算≤${money(budget)}` : ''}）的商品。可以尝试：\n1. 提高预算\n2. 换一个品类\n3. 放宽关键词`,
        intent,
        steps,
      };
    }

    // 歧义澄清：太宽泛的请求
    if (data.total > 10 && !category && !budget && !extractSearchWord(text)) {
      return {
        reply: `商城共有 ${data.total} 件商品，一下子推荐太多会挑花眼。可以告诉我：\n1. 想要的品类（耳机 / 键盘 / 台灯 / 音箱…）\n2. 预算范围（例如 500 元以内）\n这样我能推荐得更精准～`,
        intent,
        steps: [...steps, { phase: '歧义澄清', detail: '请求过于宽泛，引导用户补充品类或预算' }],
      };
    }

    // 组装推荐回复
    const top = data.list.slice(0, 3);
    lastRecommend = top;
    let reply = '';
    if (budget && category) {
      reply = `在 **${category}** 品类、预算 ${money(budget)} 以内，为你找到 ${data.total} 件商品，最推荐这几款：\n`;
    } else if (budget) {
      reply = `预算 ${money(budget)} 以内的高性价比选择如下：\n`;
    } else if (category) {
      reply = `**${category}** 品类最热门的几款：\n`;
    } else {
      reply = `为你找到 ${data.total} 件相关商品，推荐如下：\n`;
    }
    top.forEach((p, i) => {
      reply += `${i + 1}. **${p.name}** ${money(p.price)} · ${p.tags ? p.tags.join('/') : p.category} · 评分 ${p.rating}\n   ${p.description}\n`;
    });
    reply += `想加入购物车或看更多，直接告诉我，例如「把第 1 款加购」或「再便宜一点的」。`;

    return {
      reply,
      intent,
      steps,
      rich: top.map(productRichHtml).join(''),
    };
  }

  /** 提取搜索关键词（去掉疑问词与约束词） */
  function extractSearchWord(text) {
    const cleaned = text
      .replace(/推荐|有什么|看看|找(个|一下|点|一个)?|搜索|查(一)?下|买|想要|帮我|请|麻烦/g, '')
      .replace(/(\d+)\s*元.*/g, '')
      .replace(/以内|以下|左右|便宜|贵的?|好一点的?/g, '')
      .trim();
    if (cleaned.length < 2) return '';
    return cleaned.slice(0, 12);
  }

  /* ================= 执行待确认操作 ================= */
  async function executePendingConfirm(confirmed) {
    const action = pendingConfirm;
    if (!action) return null;
    pendingConfirm = null;
    const steps = [{ phase: '用户确认', detail: '用户同意执行写入操作' }];
    try {
      let result;
      switch (action.type) {
        case 'addToCart': {
          const r = await tools.addToCart({ productId: action.payload.productId, quantity: action.payload.quantity });
          result = `已将 **${r.product.name}**（${money(r.product.price)} × ${action.payload.quantity}件）加入购物车，当前共 ${r.cart.length} 种商品。`;
          break;
        }
        case 'updateCartItem': {
          const r = await tools.updateCartItem(action.payload);
          result = action.payload.quantity === 0
            ? '已从购物车移除该商品。'
            : `已将该商品数量调整为 ${action.payload.quantity} 件。`;
          break;
        }
        case 'removeFromCart': {
          await tools.removeFromCart(action.payload);
          result = '已从购物车移除该商品。';
          break;
        }
        case 'createOrder': {
          const order = await tools.createOrder({ customer: {} });
          result = `🎉 下单成功！\n订单编号：**${order.id}**\n订单状态：${order.status}\n订单总价：**${money(order.total)}**\n\n可以点击下方按钮查看订单详情，或继续购物。`;
          break;
        }
        default:
          result = '操作已完成。';
      }
      steps.push({ phase: '调用工具', tool: action.type, args: action.payload, result: '执行成功' });
      return { reply: result, intent: 'executed', steps, executed: action.type };
    } catch (e) {
      steps.push({ phase: '异常处理', detail: `${e.message}，已尝试说明并回退` });
      return {
        reply: `操作没有成功：${e.message}\n你可以重新描述需求，我换个方式帮你处理。`,
        intent: 'executed',
        steps,
      };
    }
  }

  /* ================= UI 交互（由 app.js 调用） ================= */
  function renderMsg(role, html) {
    const body = document.getElementById('agentBody');
    const wrap = document.createElement('div');
    wrap.className = `msg ${role}`;
    wrap.innerHTML = `
      <div class="msg-avatar">${role === 'user' ? '🧑' : '🤖'}</div>
      <div class="msg-bubble">${html}</div>`;
    body.appendChild(wrap);
    body.scrollTop = body.scrollHeight;
    return wrap.querySelector('.msg-bubble');
  }

  async function send(text) {
    const body = document.getElementById('agentBody');
    renderMsg('user', escapeHtml(text));
    history.push({ role: 'user', text });
    saveHistory();

    // 处理中状态
    const thinking = renderMsg('agent', '<span class="typing-caret">▍</span>');
    thinking.style.opacity = 0.6;
    await new Promise((r) => setTimeout(r, 300));

    try {
      const res = await handle(text);
      if (!res) {
        thinking.innerHTML = '请稍等，我没有完全理解你的意思，能再说一遍吗？';
        history.push({ role: 'assistant', text: '请稍等，我没有完全理解你的意思，能再说一遍吗？' });
        saveHistory();
        return;
      }

      // 渲染执行步骤面板
      let html = '';
      if (res.steps && res.steps.length) {
        html += `
          <div class="step-panel open">
            <div class="step-head"><span class="arrow">▸</span> 执行过程（思考 → 调用 → 结果）</div>
            <div class="step-list">
              ${res.steps.map((s, i) => `
                <div class="step-item done">
                  <span class="step-badge">${i + 1}</span>
                  <span><b>${s.phase}</b>${s.tool ? ` · ${s.tool}(${JSON.stringify(s.args).slice(0, 60)})` : ''}<br/>${s.detail || ''}${s.result ? `<br/><i>结果：${s.result}</i>` : ''}</span>
                </div>`).join('')}
            </div>
          </div>`;
      }

      // 富消息（商品卡片）
      if (res.rich) html += res.rich;

      // 纯文本
      const textEl = document.createElement('div');
      textEl.style.marginTop = html ? '0.25rem' : '0';
      thinking.appendChild(textEl);
      if (html) {
        thinking.innerHTML = html;
        const textWrap = document.createElement('div');
        textWrap.style.marginTop = '0.35rem';
        textWrap.style.marginBottom = '0.15rem';
        thinking.appendChild(textWrap);
        streamText(textWrap, res.reply);
      } else {
        streamText(thinking, res.reply);
      }

      history.push({ role: 'assistant', text: res.reply });
      saveHistory();

      // 执行完成后的动作回调（例如下单成功）
      if (res.executed === 'createOrder') {
        setTimeout(() => {
          const orderId = /CLOUD-\d{8}-\d{4}/.exec(res.reply);
          if (orderId) {
            // 广播事件给 app.js 刷新购物车与跳转
            document.dispatchEvent(new CustomEvent('agent:order-created', { detail: { orderId: orderId[0] } }));
          }
        }, 1200);
      } else if (res.executed) {
        // 写入操作完成 → 通知刷新购物车徽标
        document.dispatchEvent(new CustomEvent('agent:cart-updated'));
      }
    } catch (e) {
      thinking.innerHTML = `处理出错了：${escapeHtml(e.message)}。请重试或换个说法～`;
    }
  }

  /** 加载历史（刷新后恢复会话） */
  function restoreHistory() {
    const body = document.getElementById('agentBody');
    body.innerHTML = '';
    for (const h of history) {
      renderMsg(h.role, escapeHtml(h.text));
    }
    if (!history.length) {
      // 欢迎语
      renderMsg('agent', '你好！我是云屋商城的 AI 购物助手，可以帮你找商品、比价格、加购物车甚至直接下单。试试问我：\n\n「有没有 500 元以内的降噪耳机？」\n「帮我买刚才推荐的那款」');
    }
  }

  function resetHistory() {
    history = [];
    saveHistory();
    lastRecommend = null;
    pendingConfirm = null;
    restoreHistory();
  }

  return { send, restoreHistory, resetHistory, handle };
})();
