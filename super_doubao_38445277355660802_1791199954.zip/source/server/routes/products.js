/**
 * 商品路由：GET /api/products 列表（支持 keyword/category/价格区间/分页/排序）
 *           GET /api/products/:id 详情
 */
const express = require('express');
const db = require('../db');

const router = express.Router();

/** 解析数字参数，非法返回 null */
function toNumber(v) {
  if (v === undefined || v === null || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** 商品列表 + 搜索 / 筛选 / 分页 / 排序 */
router.get('/', (req, res) => {
  const { keyword, category, sort } = req.query;
  const minPrice = toNumber(req.query.minPrice);
  const maxPrice = toNumber(req.query.maxPrice);
  const page = Math.max(1, toNumber(req.query.page) || 1);
  const pageSize = Math.min(60, Math.max(1, toNumber(req.query.pageSize) || 12));

  let list = db.getProducts();

  // 关键词搜索：名称 / 简介 / 标签
  if (keyword && keyword.trim()) {
    const kw = keyword.trim().toLowerCase();
    list = list.filter((p) =>
      [p.name, p.description, p.category, ...(p.tags || [])]
        .join(' ')
        .toLowerCase()
        .includes(kw)
    );
  }

  // 分类筛选
  if (category && category.trim()) {
    list = list.filter((p) => p.category === category.trim());
  }

  // 价格区间筛选
  if (minPrice !== null) list = list.filter((p) => p.price >= minPrice);
  if (maxPrice !== null) list = list.filter((p) => p.price <= maxPrice);

  // 排序：recommended(默认按销量) | priceAsc | priceDesc | sales | rating
  switch (sort) {
    case 'priceAsc':
      list.sort((a, b) => a.price - b.price);
      break;
    case 'priceDesc':
      list.sort((a, b) => b.price - a.price);
      break;
    case 'sales':
      list.sort((a, b) => b.sales - a.sales);
      break;
    case 'rating':
      list.sort((a, b) => b.rating - a.rating);
      break;
    default:
      list.sort((a, b) => b.sales - a.sales);
  }

  const total = list.length;
  const start = (page - 1) * pageSize;
  const items = list.slice(start, start + pageSize);

  res.json({
    code: 0,
    data: {
      list: items,
      total,
      page,
      pageSize,
      categories: [...new Set(db.getProducts().map((p) => p.category))],
    },
  });
});

/** 商品详情 */
router.get('/:id', (req, res) => {
  const product = db.getProducts().find((p) => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ code: 404, message: '商品不存在' });
  }
  res.json({ code: 0, data: product });
});

module.exports = router;
