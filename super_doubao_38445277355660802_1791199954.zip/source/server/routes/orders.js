/**
 * 订单路由：POST /api/orders 创建订单（模拟支付）
 *           GET  /api/orders/:id 查询订单
 */
const express = require('express');
const db = require('../db');

const router = express.Router();

/** 生成订单编号：CLOUD-YYYYMMDD-XXXX */
function genOrderNo(now) {
  const d = now || new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(
    d.getDate()
  ).padStart(2, '0')}`;
  const rand = String(Math.floor(1000 + Math.random() * 9000));
  return `CLOUD-${ymd}-${rand}`;
}

/** 创建订单（POST /api/orders） */
router.post('/', (req, res) => {
  const { items, customer } = req.body || {};

  // 参数校验
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ code: 400, message: '订单商品不能为空' });
  }

  const products = db.getProducts();
  const orderItems = [];
  let total = 0;

  for (const it of items) {
    const product = products.find((p) => p.id === it.productId);
    if (!product) {
      return res.status(400).json({ code: 400, message: `商品不存在: ${it.productId}` });
    }
    const quantity = Math.floor(Number(it.quantity));
    if (!Number.isFinite(quantity) || quantity <= 0) {
      return res.status(400).json({ code: 400, message: `商品数量非法: ${it.productId}` });
    }
    if (quantity > product.stock) {
      return res.status(400).json({ code: 400, message: `「${product.name}」库存不足` });
    }
    orderItems.push({
      productId: product.id,
      name: product.name,
      image: product.image,
      price: product.price,
      quantity,
      subtotal: product.price * quantity,
    });
    total += product.price * quantity;
  }

  const now = new Date();
  const order = {
    id: genOrderNo(now),
    items: orderItems,
    total,
    customer: {
      name: (customer && customer.name) || '',
      phone: (customer && customer.phone) || '',
      address: (customer && customer.address) || '',
    },
    status: '已支付', // 模拟支付：下单即视为已支付
    createdAt: now.toISOString(),
    paidAt: now.toISOString(),
  };

  // 持久化订单 + 扣减库存
  const orders = db.getOrders();
  orders.unshift(order);
  db.saveOrders(orders);

  const updated = products.map((p) => {
    const sold = orderItems.find((o) => o.productId === p.id);
    return sold ? { ...p, stock: p.stock - sold.quantity, sales: p.sales + sold.quantity } : p;
  });
  require('fs').writeFileSync(
    require('path').join(db.DATA_DIR, 'products.json'),
    JSON.stringify(updated, null, 2),
    'utf-8'
  );

  res.status(201).json({ code: 0, data: order });
});

/** 订单列表（GET /api/orders，演示环境返回全部） */
router.get('/', (req, res) => {
  res.json({ code: 0, data: db.getOrders() });
});

/** 查询订单（GET /api/orders/:id） */
router.get('/:id', (req, res) => {
  const order = db.getOrders().find((o) => o.id === req.params.id);
  if (!order) {
    return res.status(404).json({ code: 404, message: '订单不存在' });
  }
  res.json({ code: 0, data: order });
});

module.exports = router;
