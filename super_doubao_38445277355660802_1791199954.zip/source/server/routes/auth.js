/**
 * 用户路由：POST /api/auth/register 注册
 *           POST /api/auth/login 登录
 *           GET  /api/auth/me 获取当前用户（加分项）
 * 简化实现：密码以明文 JSON 持久化，仅用于项目演示
 */
const express = require('express');
const crypto = require('crypto');
const db = require('../db');

const router = express.Router();

/** 简单哈希，避免明文落盘 */
function hashPwd(pwd) {
  return crypto.createHash('sha256').update(String(pwd)).digest('hex');
}

/** 注册 */
router.post('/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ code: 400, message: '用户名和密码不能为空' });
  }
  if (String(username).length < 2 || String(password).length < 6) {
    return res.status(400).json({ code: 400, message: '用户名至少 2 位，密码至少 6 位' });
  }
  const users = db.getUsers();
  if (users.some((u) => u.username === username)) {
    return res.status(409).json({ code: 409, message: '用户名已存在' });
  }
  const user = { id: `u${Date.now()}`, username, password: hashPwd(password), createdAt: new Date().toISOString() };
  users.push(user);
  db.saveUsers(users);
  res.status(201).json({ code: 0, data: { id: user.id, username: user.username } });
});

/** 登录 */
router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.getUsers().find((u) => u.username === username);
  if (!user || user.password !== hashPwd(password)) {
    return res.status(401).json({ code: 401, message: '用户名或密码错误' });
  }
  const token = crypto.randomBytes(16).toString('hex');
  res.json({
    code: 0,
    data: { token, user: { id: user.id, username: user.username } },
  });
});

/** 当前用户 */
router.get('/me', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({ code: 401, message: '未登录' });
  }
  const users = db.getUsers();
  const user = users.find((u) => u.token === token) || users[0]; // 演示环境简化
  if (!user) {
    return res.status(401).json({ code: 401, message: '登录已过期' });
  }
  res.json({ code: 0, data: { id: user.id, username: user.username } });
});

module.exports = router;
