/**
 * 云屋 CLOUD 商城 - 后端服务入口
 * Node + Express：静态托管前端 + 商品/订单/用户 API
 */
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// 静态资源：前端页面
app.use(express.static(path.join(__dirname, '..', 'public')));

// 健康检查
app.get('/api/health', (req, res) => res.json({ code: 0, data: 'ok' }));

// 业务路由
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/auth', require('./routes/auth'));

// 404 处理
app.use('/api', (req, res) => res.status(404).json({ code: 404, message: '接口不存在' }));

// 前端路由兜底：所有非 API 请求返回首页（前端为单页应用，自行处理路由）
app.get(/^\/(?!api\/).*/, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// 统一错误处理
app.use((err, req, res, next) => {
  console.error('[server]', err.message);
  res.status(500).json({ code: 500, message: '服务器内部错误' });
});

app.listen(PORT, () => {
  console.log(`✔ 云屋 CLOUD 商城后端已启动: http://localhost:${PORT}`);
});
