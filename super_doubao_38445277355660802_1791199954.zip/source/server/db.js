/**
 * 云屋 CLOUD 商城 - 数据持久化层
 * 使用 JSON 文件作为轻量数据库：商品 / 订单 / 用户
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

/** 读取 JSON 文件（不存在则返回空结构） */
function readJson(file, fallback) {
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch (err) {
    console.error(`[db] 读取 ${file} 失败:`, err.message);
  }
  return fallback;
}

/** 写入 JSON 文件（原子写入：先写临时文件再重命名） */
function writeJson(file, data) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmp, file);
}

/** 确保数据目录存在 */
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- 商品 ---------- */
function getProducts() {
  return readJson(PRODUCTS_FILE, []);
}

/* ---------- 订单 ---------- */
function getOrders() {
  return readJson(ORDERS_FILE, []);
}

function saveOrders(orders) {
  writeJson(ORDERS_FILE, orders);
}

/* ---------- 用户 ---------- */
function getUsers() {
  return readJson(USERS_FILE, []);
}

function saveUsers(users) {
  writeJson(USERS_FILE, users);
}

module.exports = {
  DATA_DIR,
  getProducts,
  getOrders,
  saveOrders,
  getUsers,
  saveUsers,
};
